"use strict";

const FiltroRangoFechaHoraNulo = function () {
    this.pasa = (consumo) => true;
}

module.exports = FiltroRangoFechaHoraNulo;
